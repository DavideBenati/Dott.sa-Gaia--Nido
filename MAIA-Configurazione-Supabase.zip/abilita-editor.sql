-- Sostituire il segnaposto con l'UID dell'account confermato di Gaia.
-- Abilita le bozze, non inventa una verifica professionale. Vedere LEGGIMI.md.
insert into private.editor_memberships (user_id,professional_name,professional_role,qualification_verified)
values ('SOSTITUIRE-CON-UID-REALE'::uuid,'Gaia Brunetti','Ostetrica',false)
on conflict(user_id) do update set active=true;
