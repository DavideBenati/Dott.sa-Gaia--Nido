"use strict";
const catalog = {
  postpartum: { name: "Postpartum Box", cents: 4900 },
  breastfeeding: { name: "Breastfeeding Kit", cents: 3900 },
};
// Only anonymous product quantities are stored; no customer or payment data.
let quantities = {};
try {
  const saved = JSON.parse(localStorage.getItem("ninni-meli-shop-demo") || "{}");
  for (const id of Object.keys(catalog)) {
    if (Number.isInteger(saved?.[id]) && saved[id] > 0 && saved[id] <= 20) quantities[id] = saved[id];
  }
} catch { /* The cart works in memory when storage is unavailable. */ }
const cart = document.querySelector("#cart");
const money = cents => new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(cents / 100);
function render() {
  const items = document.querySelector("#cart-items");
  items.replaceChildren();
  let total = 0, count = 0;
  for (const [id, quantity] of Object.entries(quantities)) {
    const product = catalog[id];
    total += product.cents * quantity; count += quantity;
    const row = document.createElement("div"); row.className = "cart-row";
    const description = document.createElement("div");
    const name = document.createElement("h3"); name.textContent = product.name;
    const price = document.createElement("p"); price.textContent = money(product.cents) + " / kit";
    description.append(name, price);
    const controls = document.createElement("div"); controls.className = "quantity";
    for (const [label, text, delta] of [["Riduci", "−", -1], ["Aumenta", "+", 1]]) {
      const button = document.createElement("button"); button.textContent = text;
      button.setAttribute("aria-label", `${label} quantità ${product.name}`);
      button.disabled = delta === 1 && quantity >= 20;
      button.addEventListener("click", () => {
        const position = [...controls.children].indexOf(button);
        change(id, delta);
        const newControls = document.querySelector(`[data-product="${id}"] .quantity`);
        (newControls?.children[position] || document.querySelector("#close-cart")).focus();
      });
      controls.append(button);
      if (delta === -1) { const value = document.createElement("span"); value.textContent = quantity; controls.append(value); }
    }
    row.dataset.product = id; row.append(description, controls); items.append(row);
  }
  if (!count) { const empty = document.createElement("p"); empty.className = "empty"; empty.textContent = "La tua borsa è ancora vuota. Un piccolo inizio ti aspetta."; items.append(empty); }
  document.querySelector("#cart-count").textContent = count;
  document.querySelector("#cart-total").textContent = money(total);
}
function change(id, delta) {
  const next = Math.min(20, Math.max(0, (quantities[id] || 0) + delta));
  if (next) quantities[id] = next; else delete quantities[id];
  try { localStorage.setItem("ninni-meli-shop-demo", JSON.stringify(quantities)); } catch { /* Optional persistence. */ }
  render();
  document.querySelector("#status").textContent = `${catalog[id].name}: ${next} nella borsa demo.`;
}
document.querySelectorAll("[data-add]").forEach(button => button.addEventListener("click", () => { change(button.dataset.add, 1); cart.showModal(); }));
document.querySelector("#open-cart").addEventListener("click", () => cart.showModal());
document.querySelector("#close-cart").addEventListener("click", () => cart.close());
document.querySelector("#continue").addEventListener("click", () => cart.close());
cart.addEventListener("click", event => { if (event.target === cart) { const r = cart.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) cart.close(); } });
render();
