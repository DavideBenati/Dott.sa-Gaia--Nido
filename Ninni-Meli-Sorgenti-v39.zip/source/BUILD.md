# Sorgenti NinniMeli v39

Modificare index.html, source/shop.source.js e source/style.source.css. I file shop.js e style.css alla radice sono generati; release-v39 è un output generato.

Per ricompilare usando gli strumenti già installati nel workspace:
node source/build_assets.cjs /workspace/GAIA_NIDO/package.json

Versioni utilizzate: Node.js 24, Terser 5.51.2, Lightning CSS 1.33.0. La creazione dello ZIP usa la libreria standard Python. I WOFF2 sono già inclusi; non serve riconvertire i font per compilare.

I font sono stati convertiti da TTF a WOFF2 con fontTools e Brotli 1.2.1; cmap e numero di glifi sono stati confrontati con gli originali. Le licenze originali sono incluse.

Il processo ricrea release-v39 e iterations/Ninni-Meli-Sito-v39.zip. Non modificare manualmente l’output generato. Hash e cache devono aggiornarsi insieme: usare lo script, senza rinominare a mano risorse nel pacchetto.

Il logo resta all’URL pubblico Supabase fornito dall’utente. Il codice contiene soltanto la chiave publishable destinata al browser, non segreti server.
