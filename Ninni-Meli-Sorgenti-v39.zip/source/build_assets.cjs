// Usage: node source/build_assets.cjs /path/to/project-with-tools/package.json
const fs=require('node:fs');const path=require('node:path');const{createRequire}=require('node:module');const{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');const from=process.argv[2];
if(!from)throw new Error('Provide package.json of an installation with terser 5.51.2 and lightningcss 1.33.0');
const load=createRequire(path.resolve(from));
(async()=>{
 const css=fs.readFileSync(path.join(__dirname,'style.source.css'));
 fs.writeFileSync(path.join(root,'style.css'),load('lightningcss').transform({filename:'style.css',code:css,minify:true}).code);
 const js=fs.readFileSync(path.join(__dirname,'shop.source.js'),'utf8');
 const result=await load('terser').minify(js,{ecma:2022,compress:{passes:2},mangle:true,format:{comments:false}});
 if(result.error)throw result.error;fs.writeFileSync(path.join(root,'shop.js'),result.code);
 execFileSync('python',[path.join(__dirname,'package_release.py')],{stdio:'inherit'});
})().catch(error=>{console.error(error);process.exit(1)});
