"""Package already optimized assets. Run from anywhere; no credentials required."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import json, re, shutil
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'release-v39'
if OUT.exists(): shutil.rmtree(OUT)
(OUT/'assets').mkdir(parents=True)
css=(ROOT/'style.css').read_text()
html=(ROOT/'index.html').read_text()
for font in sorted((ROOT/'assets').glob('*.woff2')):
    name=font.stem+'.'+sha256(font.read_bytes()).hexdigest()[:12]+'.woff2'
    shutil.copyfile(font,OUT/'assets'/name)
    css=css.replace(font.name,name)
    html=html.replace(font.name,name)
for license in sorted((ROOT/'assets').glob('*LICENSE.txt')): shutil.copyfile(license,OUT/'assets'/license.name)
cssname='style.'+sha256(css.encode()).hexdigest()[:12]+'.css'
js=(ROOT/'shop.js').read_bytes()
jsname='shop.'+sha256(js).hexdigest()[:12]+'.js'
(OUT/cssname).write_text(css)
(OUT/jsname).write_bytes(js)
html=re.sub(r'style\.css\?v=\d+',cssname,html)
html=re.sub(r'shop\.js\?v=\d+',jsname,html)
(OUT/'index.html').write_text(html)
headers=(ROOT/'_headers').read_text().split('/\n  Cache-Control: no-cache')[0]
headers+='''/\n  Cache-Control: no-cache\n/index.html\n  Cache-Control: no-cache\n/shop.*.js\n  Cache-Control: public, max-age=31536000, immutable\n/style.*.css\n  Cache-Control: public, max-age=31536000, immutable\n/assets/*\n  Cache-Control: public, max-age=31536000, immutable\n'''
(OUT/'_headers').write_text(headers)
manifest={'version':39,'files':{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.rglob('*')) if p.is_file()}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with ZipFile(ROOT/'iterations'/'Ninni-Meli-Sito-v39.zip','w',ZIP_DEFLATED) as archive:
    for p in sorted(OUT.rglob('*')):
        if p.is_file(): archive.write(p,p.relative_to(OUT))
print('Pacchetto v39 con hash, manifest e cache immutabile creato')
