"use strict";
// Keep the brand readable if the public image is temporarily unavailable.
document.querySelectorAll("[data-brand-logo]").forEach(image => {
  const fallback = image.parentElement.querySelector(".logo-fallback");
  const showFallback = () => { image.hidden = true; fallback.hidden = false; };
  image.addEventListener("error", showFallback);
  if (image.complete && !image.naturalWidth) showFallback();
});

// Publishable browser key: never replace with a secret/service-role key.
const SUPABASE_URL = "https://thyonlpyemgjuqjclqte.supabase.co";
const SUPABASE_KEY = "sb_publishable_BcDEfYz-x9dJez6NiCr0yA_X6THD7mA";
const API_URL = "https://ninni-meli-api.ostetricamaia.workers.dev";
let checkoutReady = false;
let catalogReady = false;
let checkoutBusy = false;
let selectedProductId = null;
const STORAGE_KEY = "ninni-meli-catalog-demo-v2";
const catalog = new Map();
let quantities = {};
try {
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  if (saved && typeof saved === "object" && !Array.isArray(saved)) {
    for (const [id, value] of Object.entries(saved)) {
      if (/^[a-f0-9-]{36}$/i.test(id) && Number.isInteger(value) && value > 0 && value <= 20) quantities[id] = value;
    }
  }
} catch { /* Optional browser storage; memory-only cart remains usable. */ }
const cart = document.querySelector("#cart");
const products = document.querySelector("#products");
const catalogStatus = document.querySelector("#catalog-status");
const retry = document.querySelector("#retry-catalog");
const money = cents => new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(cents / 100);
function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function persist() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(quantities)); } catch { /* Optional persistence. */ }
}
function maxQuantity(product) { return Math.min(20, product.stock); }
function renderCart() {
  const items = document.querySelector("#cart-items");
  items.replaceChildren();
  let total = 0, count = 0;
  for (const [id, quantity] of Object.entries(quantities)) {
    const product = catalog.get(id);
    if (!product) continue;
    total += product.price_cents * quantity; count += quantity;
    const row = element("div", "cart-row");
    const description = element("div");
    description.append(element("h3", "", product.name), element("p", "", money(product.price_cents) + " / kit"), element("p", "line-total", `Totale articolo: ${money(product.price_cents * quantity)}`));
    const remove = element("button", "remove-item", "Rimuovi");
    remove.setAttribute("aria-label", `Rimuovi ${product.name} dalla borsa`);
    remove.addEventListener("click", () => { if (checkoutBusy) return; change(id, -quantity); document.querySelector("#close-cart").focus(); });
    description.append(remove);
    const controls = element("div", "quantity");
    for (const [label, text, delta] of [["Riduci", "−", -1], ["Aumenta", "+", 1]]) {
      const button = element("button", "", text);
      button.setAttribute("aria-label", `${label} quantità ${product.name}`);
      button.disabled = delta === 1 && quantity >= maxQuantity(product);
      button.addEventListener("click", () => {
        const position = [...controls.children].indexOf(button);
        change(id, delta);
        const nextRow = [...items.children].find(child => child.dataset.product === id);
        (nextRow?.querySelector(".quantity")?.children[position] || document.querySelector("#close-cart")).focus();
      });
      controls.append(button);
      if (delta === -1) controls.append(element("span", "", quantity));
    }
    row.dataset.product = id;
    row.append(description, controls); items.append(row);
  }
  if (!count) {
    items.append(element("p", "empty", "La tua borsa è ancora vuota. Puoi scoprire i prodotti pubblicati nella collezione."));
    const explore = element("a", "empty-cart-link", "Esplora la collezione ↗"); explore.href = "#collezione";
    explore.addEventListener("click", () => cart.close()); items.append(explore);
  }
  document.querySelector("#open-cart").setAttribute("aria-label", `La tua borsa, ${count} ${count === 1 ? "articolo" : "articoli"}`);
  document.querySelectorAll("[data-open-cart]").forEach(button => button.setAttribute("aria-label", `La borsa, ${count} ${count === 1 ? "articolo" : "articoli"}`));
  document.querySelector("#cart-count").textContent = count;
  document.querySelectorAll("[data-cart-count]").forEach(node => { node.textContent = count; });
  document.querySelector("#cart-total").textContent = money(total);
  updateCheckoutButton(count);
}
function change(id, delta) {
  if (checkoutBusy) return;
  const product = catalog.get(id);
  if (!product) return;
  const next = Math.min(maxQuantity(product), Math.max(0, (quantities[id] || 0) + delta));
  if (next) quantities[id] = next; else delete quantities[id];
  persist(); renderCart();
  document.querySelector("#status").textContent = `${product.name}: ${next} nella borsa demo.`;
}
function imageURL(path) {
  if (typeof path !== "string" || !path.trim()) return null;
  try {
    if (/^https?:/i.test(path)) {
      const url = new URL(path);
      return url.origin === SUPABASE_URL && url.pathname.startsWith("/storage/v1/object/public/product-images/") ? url.href : null;
    }
    const parts = path.split("/");
    if (parts.some(part => !part || part === "." || part === "..")) return null;
    return `${SUPABASE_URL}/storage/v1/object/public/product-images/${parts.map(encodeURIComponent).join("/")}`;
  } catch { return null; }
}
function renderProducts(rows) {
  products.replaceChildren();
  for (const product of rows) {
    const article = element("article", "product");
    const art = element("div", "product-art " + (product.slug === "breastfeeding-kit" ? "sage" : "peach"));
    const label = element("span", "art-foot", "ILLUSTRAZIONE SEGNAPOSTO · FOTO IN PREPARAZIONE");
    const box = element("div", "mini-box");
    box.append(element("span", "", "✳ Ninni Meli")); art.append(box, label);
    const url = imageURL(product.image_path);
    if (url) {
      const img = element("img", "product-photo"); img.alt = product.name; img.loading = "lazy";
      img.addEventListener("load", () => { box.hidden = true; label.hidden = true; });
      img.addEventListener("error", () => { img.remove(); box.hidden = false; label.hidden = false; });
      img.src = url; art.append(img);
    }
    const title = element("div", "product-title");
    title.append(element("h3", "", product.name), element("span", "", money(product.price_cents)));
    const availability = element("p", "", product.stock > 0 ? "Disponibile nel catalogo · Acquisti non ancora attivi" : "Al momento non disponibile");
    const add = element("button", "button outline", product.stock > 0 ? "Aggiungi alla borsa demo +" : "Non disponibile");
    add.disabled = product.stock === 0;
    add.addEventListener("click", () => { change(product.id, 1); cart.showModal(); });
    const provenance = element("details", "product-provenance");
    provenance.append(element("summary", "", "Materiali, origine e cura"), element("p", "", "Le informazioni di dettaglio su materiali, luogo di produzione e manutenzione saranno completate prima della vendita. Consulta la descrizione aggiornata e i criteri con cui stiamo selezionando i fornitori."));
    const supplyLink = element("a", "product-supply-link", "Scopri i criteri della filiera ↗");
    supplyLink.href = "#filiera";
    provenance.append(supplyLink);
    const readMore = element("button", "details-button", "Leggi la scheda completa ↗");
    readMore.setAttribute("aria-label", `Leggi la scheda di ${product.name}`);
    readMore.setAttribute("aria-haspopup", "dialog"); readMore.setAttribute("aria-controls", "product-detail");
    readMore.addEventListener("click", () => openProductDetail(product.id));
    article.append(art, title, element("p", "", product.description), readMore, provenance, availability, add);
    products.append(article);
  }
}
function validateRows(rows) {
  if (!Array.isArray(rows)) throw new Error("Invalid catalog");
  const ids = new Set();
  for (const p of rows) {
    if (!p || typeof p.id !== "string" || !/^[a-f0-9-]{36}$/i.test(p.id) || ids.has(p.id) || typeof p.slug !== "string" || typeof p.name !== "string" || typeof p.description !== "string" || p.currency !== "EUR" || !Number.isSafeInteger(p.price_cents) || p.price_cents < 0 || !Number.isSafeInteger(p.stock) || p.stock < 0) throw new Error("Invalid product");
    ids.add(p.id);
  }
  return rows;
}
async function loadCatalog() {
  catalogReady = false; updateCheckoutButton(0);
  document.querySelector("#catalog-empty").hidden = true;
  document.querySelector("#catalog-tools").hidden = true;
  document.querySelector("#catalog-no-results").hidden = true;
  retry.hidden = true; retry.disabled = true; products.setAttribute("aria-busy", "true");
  catalogStatus.textContent = "Stiamo preparando i tuoi piccoli essenziali…";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/products?select=id,slug,name,description,price_cents,currency,stock,image_path&published=eq.true&order=created_at.asc`, {
      headers: { apikey: SUPABASE_KEY }, signal: controller.signal, cache: "no-store", credentials: "omit",
    });
    if (!response.ok) throw new Error("Catalog unavailable");
    const rows = validateRows(await response.json());
    const previousProducts = new Map(catalog);
    let basketUpdated = false;
    for (const [id, quantity] of Object.entries(quantities)) {
      const next = rows.find(product => product.id === id);
      const before = previousProducts.get(id);
      if (!next || next.stock < quantity || (before && before.price_cents !== next.price_cents)) basketUpdated = true;
    }
    catalog.clear(); rows.forEach(p => catalog.set(p.id, p));
    for (const [id, value] of Object.entries(quantities)) {
      const product = catalog.get(id);
      if (!product || product.stock === 0) delete quantities[id];
      else quantities[id] = Math.min(value, maxQuantity(product));
    }
    catalogReady = true; persist(); applyCatalogView(); renderCart();
    const feedback = document.querySelector("#cart-feedback");
    feedback.hidden = !basketUpdated;
    feedback.textContent = basketUpdated ? "La borsa è stata aggiornata secondo i prezzi e le disponibilità attuali. Controlla il riepilogo prima di proseguire." : "";
    const detail = document.querySelector("#product-detail");
    if (detail.open && selectedProductId) {
      detail.close();
      if (catalog.has(selectedProductId)) openProductDetail(selectedProductId);
      else document.querySelector("#status").textContent = "Il prodotto non è più presente nel catalogo.";
    }
    catalogStatus.textContent = rows.length ? "" : "La collezione è in preparazione. I primi kit saranno presentati qui appena pronti.";
    document.querySelector("#catalog-empty").hidden = rows.length > 0;
  } catch {
    products.replaceChildren(); catalog.clear(); renderCart();
    catalogStatus.textContent = "Non riusciamo a caricare il catalogo. Riprova tra poco.";
    retry.hidden = false;
  } finally { clearTimeout(timeout); retry.disabled = false; products.setAttribute("aria-busy", "false"); }
}
retry.addEventListener("click", loadCatalog);
// Refresh on return to the page: remove withdrawn products and refresh prices/stock.
window.addEventListener("pageshow", event => { if (event.persisted) loadCatalog(); });
document.querySelector("#open-cart").addEventListener("click", () => cart.showModal());
document.querySelectorAll("[data-open-cart]").forEach(button => button.addEventListener("click", () => cart.showModal()));
document.querySelector("#close-cart").addEventListener("click", () => cart.close());
document.querySelector("#continue").addEventListener("click", () => cart.close());
cart.addEventListener("click", event => { if (event.target === cart) { const r = cart.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) cart.close(); } });
renderCart(); loadCatalog();

function updateCheckoutButton(count = Object.values(quantities).reduce((sum, n) => sum + n, 0)) {
  const button = document.querySelector("#checkout-action");
  button.disabled = !checkoutReady || !catalogReady || checkoutBusy || !count;
  button.textContent = checkoutBusy ? "Preparazione del pagamento di prova…" : checkoutReady ? "Vai al pagamento di prova — nessun addebito reale" : "Acquisti disponibili prossimamente";
}
async function loadCheckoutStatus() {
  try {
    const response = await fetch(`${API_URL}/health`, { cache: "no-store", credentials: "omit", signal: AbortSignal.timeout(10000) });
    if (!response.ok) return;
    const state = await response.json();
    checkoutReady = state.service === "ninni-meli-api" && state.sandbox_only === true && state.checkout_enabled === true;
  } catch { checkoutReady = false; }
  updateCheckoutButton();
}
document.querySelector("#checkout-action").addEventListener("click", async () => {
  if (!checkoutReady || checkoutBusy) return;
  const message = document.querySelector("#checkout-message");
  checkoutBusy = true; updateCheckoutButton(); message.textContent = "";
  // Lock quantity controls until the request completes to avoid a changed basket.
  document.querySelectorAll(".quantity button").forEach(button => { button.disabled = true; });
  try {
    const items = Object.entries(quantities).map(([id, quantity]) => ({ id, quantity })).sort((a,b) => a.id.localeCompare(b.id));
    const basket = JSON.stringify(items);
    let attempt;
    try { attempt = JSON.parse(sessionStorage.getItem("ninni-meli-payment-attempt") || "null"); } catch {}
    if (!attempt || attempt.basket !== basket || !/^[a-f0-9-]{36}$/i.test(attempt.id || "")) {
      attempt = { basket, id: crypto.randomUUID() };
    }
    // In-memory fallback also keeps retries idempotent if browser storage is blocked.
    if (window.ninniPaymentAttempt?.basket === basket) attempt = window.ninniPaymentAttempt;
    window.ninniPaymentAttempt = attempt;
    try { sessionStorage.setItem("ninni-meli-payment-attempt", JSON.stringify(attempt)); } catch {}
    const response = await fetch(`${API_URL}/checkout`, {
      method: "POST", credentials: "omit", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ checkout_id: attempt.id, items }), signal: AbortSignal.timeout(45000),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(typeof result.error === "string" ? result.error : "Pagamento di prova non disponibile.");
    const url = new URL(result.url);
    if (result.sandbox !== true || url.protocol !== "https:" || url.hostname !== "checkout.stripe.com") throw new Error("Collegamento al pagamento non valido.");
    window.location.assign(url.href);
  } catch (error) {
    message.textContent = error.name === "TimeoutError" || error.name === "TypeError" ? "Connessione interrotta. Riprova con lo stesso carrello: non creare un nuovo tentativo." : error.message;
  } finally { checkoutBusy = false; renderCart(); }
});
const paymentReturn = new URLSearchParams(location.search).get("checkout");
if (paymentReturn === "success" || paymentReturn === "cancelled") {
  document.querySelector("#checkout-message").textContent = paymentReturn === "success"
    ? "Sei tornata dal pagamento di prova. Questa pagina non conferma l’ordine: l’esito viene verificato tramite Stripe. Nessuna spedizione reale."
    : "Sei tornata dal pagamento di prova senza completarlo. Le scorte riservate verranno liberate alla scadenza della sessione.";
  cart.showModal();
}
loadCheckoutStatus();

// Indicate the reading position in both navigation areas without moving focus.
if ("IntersectionObserver" in window) {
  const links = [...document.querySelectorAll('.main-nav a[href^="#"], .mobile-actions a[href^="#"]')];
  const observed = [...new Set(links.map(link => document.querySelector(link.getAttribute("href"))).filter(Boolean))];
  const visible = new Set();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => entry.isIntersecting ? visible.add(entry.target) : visible.delete(entry.target));
    const current = observed.find(section => visible.has(section));
    links.forEach(link => {
      if (current && link.hash === `#${current.id}`) link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    });
  }, { rootMargin: "-10% 0px -35% 0px", threshold: 0 });
  observed.forEach(section => observer.observe(section));
}

function folded(value) { return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("it").trim(); }
function applyCatalogView() {
  const query = folded(document.querySelector("#product-search").value);
  const order = document.querySelector("#product-sort").value;
  const all = [...catalog.values()];
  const rows = all.filter(product => folded(`${product.name} ${product.description}`).includes(query));
  if (order === "price-asc") rows.sort((a,b) => a.price_cents-b.price_cents || a.name.localeCompare(b.name,"it"));
  if (order === "price-desc") rows.sort((a,b) => b.price_cents-a.price_cents || a.name.localeCompare(b.name,"it"));
  if (order === "name") rows.sort((a,b) => a.name.localeCompare(b.name,"it"));
  renderProducts(rows);
  document.querySelector("#catalog-tools").hidden = all.length === 0;
  document.querySelector("#catalog-no-results").hidden = !all.length || rows.length > 0;
  document.querySelector("#catalog-results").textContent = all.length ? `${rows.length} ${rows.length === 1 ? "prodotto" : "prodotti"}${query ? ` su ${all.length}` : ""}` : "";
}
document.querySelector("#product-search").addEventListener("input", applyCatalogView);
document.querySelector("#product-sort").addEventListener("change", applyCatalogView);
document.querySelector("#clear-search").addEventListener("click", () => {
  document.querySelector("#product-search").value = ""; applyCatalogView(); document.querySelector("#product-search").focus();
});

function openProductDetail(id) {
  const product = catalog.get(id); if (!product) return;
  selectedProductId = id;
  document.querySelector("#detail-title").textContent = product.name;
  document.querySelector("#detail-price").textContent = `${money(product.price_cents)} · prezzo proposto`;
  document.querySelector("#detail-description").textContent = product.description || "Descrizione in preparazione.";
  document.querySelector("#detail-availability").textContent = product.stock ? "Presente nel catalogo. Le vendite non sono ancora attive." : "Al momento non disponibile.";
  const add = document.querySelector("#detail-add"); add.disabled = !product.stock || !catalogReady || checkoutBusy;
  add.textContent = product.stock ? "Aggiungi alla borsa demo" : "Non disponibile";
  document.querySelector("#product-detail").showModal();
}
document.querySelector("#close-detail").addEventListener("click", () => document.querySelector("#product-detail").close());
document.querySelector("#detail-supply").addEventListener("click", () => document.querySelector("#product-detail").close());
document.querySelector("#detail-add").addEventListener("click", () => {
  const product = catalog.get(selectedProductId); if (!product || !catalogReady || !product.stock || checkoutBusy) return;
  change(product.id, 1); document.querySelector("#product-detail").close(); cart.showModal();
});
document.querySelector("#product-detail").addEventListener("click", event => {
  const dialog = event.currentTarget;
  if (event.target === dialog) { const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close(); }
});

function updateConnectionNotice() { document.querySelector("#connection-notice").hidden = navigator.onLine !== false; }
window.addEventListener("offline", updateConnectionNotice);
window.addEventListener("online", updateConnectionNotice);
updateConnectionNotice();

const faqInput = document.querySelector("#faq-search");
const faqItems = [...document.querySelectorAll("#domande > details")];
function filterFAQ() {
  const query = folded(faqInput.value);
  let count = 0;
  faqItems.forEach(item => {
    const match = !query || folded(item.textContent).includes(query);
    item.hidden = !match; if (match) count++;
  });
  document.querySelector("#faq-results").textContent = !query ? "" : count ? `${count} ${count === 1 ? "risposta trovata" : "risposte trovate"}` : "Nessuna risposta corrisponde. Prova un’altra parola o mostra tutte le domande.";
  document.querySelector("#clear-faq").hidden = !query;
}
faqInput.addEventListener("input", filterFAQ);
document.querySelector("#clear-faq").addEventListener("click", () => { faqInput.value = ""; filterFAQ(); faqInput.focus(); });
