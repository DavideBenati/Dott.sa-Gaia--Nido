"use strict";
const CACHE_PREFIX = "metimaia-pwa-";
const CACHE_NAME = CACHE_PREFIX + "386cc0ad3eb090c9c30a";
const OFFLINE_URL = new URL("/offline.html", self.location.origin).href;
const OFFLINE_MARKER = '<meta name="metimaia-offline" content="v1">';

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    // Fetch one fixed, generic public document. No navigation or auth request
    // is ever put into CacheStorage, including its URL/query parameters.
    const response = await fetch(new Request(OFFLINE_URL, {
      cache: "no-store", credentials: "omit", redirect: "error"
    }));
    if (!response.ok || !(await response.clone().text()).includes(OFFLINE_MARKER)) {
      throw new Error("Generic offline page unavailable");
    }
    const cache = await caches.open(CACHE_NAME);
    await cache.put(OFFLINE_URL, response);
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter((name) => name.startsWith(CACHE_PREFIX) && name !== CACHE_NAME)
      .map((name) => caches.delete(name)));
  })());
  // Existing pages are not claimed or reloaded while someone is editing.
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    // The app sends this only after an explicit, guarded update action.
    event.waitUntil(self.skipWaiting());
  }
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  // Supabase APIs/storage, document POSTs and every non-navigation request use
  // their original network path. They are neither read from nor saved to cache.
  if (request.method !== "GET" || request.mode !== "navigate" ||
      new URL(request.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    try {
      // Keep the original Request intact: confirmation/reset query parameters
      // and credentials must reach the server unchanged. HTTP errors pass through.
      return await fetch(request, { cache: "no-store" });
    } catch {
      const cache = await caches.open(CACHE_NAME);
      const offline = await cache.match(OFFLINE_URL);
      if (!offline) throw new Error("Offline page unavailable");
      return new Response(offline.body, {
        status: 503,
        statusText: "Offline",
        headers: {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-store",
          "X-Robots-Tag": "noindex, nofollow"
        }
      });
    }
  })());
});
