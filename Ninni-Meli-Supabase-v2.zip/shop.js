"use strict";
// Publishable browser key: never replace with a secret/service-role key.
const SUPABASE_URL = "https://thyonlpyemgjuqjclqte.supabase.co";
const SUPABASE_KEY = "sb_publishable_BcDEfYz-x9dJez6NiCr0yA_X6THD7mA";
const STORAGE_KEY = "ninni-meli-catalog-demo-v2";
const catalog = new Map();
let quantities = {};
try {
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  if (saved && typeof saved === "object" && !Array.isArray(saved)) {
    for (const [id, value] of Object.entries(saved)) {
      if (/^[a-f0-9-]{36}$/i.test(id) && Number.isInteger(value) && value > 0 && value <= 20) quantities[id] = value;
    }
  }
} catch { /* Optional browser storage; memory-only cart remains usable. */ }
const cart = document.querySelector("#cart");
const products = document.querySelector("#products");
const catalogStatus = document.querySelector("#catalog-status");
const retry = document.querySelector("#retry-catalog");
const money = cents => new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(cents / 100);
function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function persist() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(quantities)); } catch { /* Optional persistence. */ }
}
function maxQuantity(product) { return Math.min(20, product.stock); }
function renderCart() {
  const items = document.querySelector("#cart-items");
  items.replaceChildren();
  let total = 0, count = 0;
  for (const [id, quantity] of Object.entries(quantities)) {
    const product = catalog.get(id);
    if (!product) continue;
    total += product.price_cents * quantity; count += quantity;
    const row = element("div", "cart-row");
    const description = element("div");
    description.append(element("h3", "", product.name), element("p", "", money(product.price_cents) + " / kit"));
    const controls = element("div", "quantity");
    for (const [label, text, delta] of [["Riduci", "−", -1], ["Aumenta", "+", 1]]) {
      const button = element("button", "", text);
      button.setAttribute("aria-label", `${label} quantità ${product.name}`);
      button.disabled = delta === 1 && quantity >= maxQuantity(product);
      button.addEventListener("click", () => {
        const position = [...controls.children].indexOf(button);
        change(id, delta);
        const nextRow = [...items.children].find(child => child.dataset.product === id);
        (nextRow?.querySelector(".quantity")?.children[position] || document.querySelector("#close-cart")).focus();
      });
      controls.append(button);
      if (delta === -1) controls.append(element("span", "", quantity));
    }
    row.dataset.product = id;
    row.append(description, controls); items.append(row);
  }
  if (!count) items.append(element("p", "empty", "La tua borsa è ancora vuota. Un piccolo inizio ti aspetta."));
  document.querySelector("#cart-count").textContent = count;
  document.querySelector("#cart-total").textContent = money(total);
}
function change(id, delta) {
  const product = catalog.get(id);
  if (!product) return;
  const next = Math.min(maxQuantity(product), Math.max(0, (quantities[id] || 0) + delta));
  if (next) quantities[id] = next; else delete quantities[id];
  persist(); renderCart();
  document.querySelector("#status").textContent = `${product.name}: ${next} nella borsa demo.`;
}
function imageURL(path) {
  if (typeof path !== "string" || !path.trim()) return null;
  try {
    if (/^https?:/i.test(path)) {
      const url = new URL(path);
      return url.origin === SUPABASE_URL && url.pathname.startsWith("/storage/v1/object/public/product-images/") ? url.href : null;
    }
    const parts = path.split("/");
    if (parts.some(part => !part || part === "." || part === "..")) return null;
    return `${SUPABASE_URL}/storage/v1/object/public/product-images/${parts.map(encodeURIComponent).join("/")}`;
  } catch { return null; }
}
function renderProducts(rows) {
  products.replaceChildren();
  for (const product of rows) {
    const article = element("article", "product");
    const art = element("div", "product-art " + (product.slug === "breastfeeding-kit" ? "sage" : "peach"));
    const label = element("span", "art-foot", "ILLUSTRAZIONE SEGNAPOSTO · FOTO IN PREPARAZIONE");
    const box = element("div", "mini-box");
    box.append(element("span", "", "✳ Ninni Meli")); art.append(box, label);
    const url = imageURL(product.image_path);
    if (url) {
      const img = element("img", "product-photo"); img.alt = product.name; img.loading = "lazy";
      img.addEventListener("load", () => { box.hidden = true; label.hidden = true; });
      img.addEventListener("error", () => { img.remove(); box.hidden = false; label.hidden = false; });
      img.src = url; art.append(img);
    }
    const title = element("div", "product-title");
    title.append(element("h3", "", product.name), element("span", "", money(product.price_cents)));
    const availability = element("p", "", product.stock > 0 ? "Disponibile nel catalogo · Acquisti non ancora attivi" : "Al momento non disponibile");
    const add = element("button", "button outline", product.stock > 0 ? "Aggiungi alla borsa demo +" : "Non disponibile");
    add.disabled = product.stock === 0;
    add.addEventListener("click", () => { change(product.id, 1); cart.showModal(); });
    article.append(art, title, element("p", "", product.description), availability, add);
    products.append(article);
  }
}
function validateRows(rows) {
  if (!Array.isArray(rows)) throw new Error("Invalid catalog");
  const ids = new Set();
  for (const p of rows) {
    if (!p || typeof p.id !== "string" || !/^[a-f0-9-]{36}$/i.test(p.id) || ids.has(p.id) || typeof p.slug !== "string" || typeof p.name !== "string" || typeof p.description !== "string" || p.currency !== "EUR" || !Number.isSafeInteger(p.price_cents) || p.price_cents < 0 || !Number.isSafeInteger(p.stock) || p.stock < 0) throw new Error("Invalid product");
    ids.add(p.id);
  }
  return rows;
}
async function loadCatalog() {
  retry.hidden = true; products.setAttribute("aria-busy", "true");
  catalogStatus.textContent = "Stiamo preparando i tuoi piccoli essenziali…";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/products?select=id,slug,name,description,price_cents,currency,stock,image_path&published=eq.true&order=created_at.asc`, {
      headers: { apikey: SUPABASE_KEY }, signal: controller.signal, cache: "no-store", credentials: "omit",
    });
    if (!response.ok) throw new Error("Catalog unavailable");
    const rows = validateRows(await response.json());
    catalog.clear(); rows.forEach(p => catalog.set(p.id, p));
    for (const [id, value] of Object.entries(quantities)) {
      const product = catalog.get(id);
      if (!product || product.stock === 0) delete quantities[id];
      else quantities[id] = Math.min(value, maxQuantity(product));
    }
    persist(); renderProducts(rows); renderCart();
    catalogStatus.textContent = rows.length ? "" : "La collezione è in preparazione. I primi kit saranno presentati qui appena pronti.";
  } catch {
    products.replaceChildren(); catalog.clear(); renderCart();
    catalogStatus.textContent = "Non riusciamo a caricare il catalogo. Riprova tra poco.";
    retry.hidden = false;
  } finally { clearTimeout(timeout); products.setAttribute("aria-busy", "false"); }
}
retry.addEventListener("click", loadCatalog);
// Refresh on return to the page: remove withdrawn products and refresh prices/stock.
window.addEventListener("pageshow", event => { if (event.persisted) loadCatalog(); });
document.querySelector("#open-cart").addEventListener("click", () => cart.showModal());
document.querySelector("#close-cart").addEventListener("click", () => cart.close());
document.querySelector("#continue").addEventListener("click", () => cart.close());
cart.addEventListener("click", event => { if (event.target === cart) { const r = cart.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) cart.close(); } });
renderCart(); loadCatalog();
